import ComponentTableBody from '../model/ComponentTableBody';
import ComponentView from './ComponentView';

export default class ComponentTableBodyView extends ComponentView<ComponentTableBody> {}
