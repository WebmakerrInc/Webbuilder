import ComponentTable from '../model/ComponentTable';
import ComponentView from './ComponentView';

export default class ComponentTableView extends ComponentView<ComponentTable> {
  events() {
    return {};
  }
}
