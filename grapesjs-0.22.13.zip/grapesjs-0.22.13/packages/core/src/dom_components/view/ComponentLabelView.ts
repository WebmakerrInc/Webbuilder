import ComponentLabel from '../model/ComponentLabel';
import ComponentLinkView from './ComponentLinkView';

export default class ComponentLabelView extends ComponentLinkView<ComponentLabel> {}
