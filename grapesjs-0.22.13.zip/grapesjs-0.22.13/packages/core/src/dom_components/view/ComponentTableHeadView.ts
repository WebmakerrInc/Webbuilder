import ComponentTableHead from '../model/ComponentTableHead';
import ComponentView from './ComponentView';

export default class ComponentTableHeadView extends ComponentView<ComponentTableHead> {}
