export function getHostName() {
  return window.location.hostname;
}
